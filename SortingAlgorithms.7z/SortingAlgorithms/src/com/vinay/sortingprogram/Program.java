package com.vinay.sortingprogram;

import com.vinay.sortingalgorithms.BubbleSort;
import com.vinay.sortingalgorithms.InsertionSort;
import com.vinay.sortingalgorithms.MergeSort;
import com.vinay.sortingalgorithms.QuickSort;
import com.vinay.sortingalgorithms.SelectionSort;

public class Program {

	// main method 
	public static void main(String[] args) {
		
		PrintArray printArray = new PrintArray();
		// array declaration 
		int arr[] = {64, 34, 25, 12, 22, 11, 90};
		
		System.out.println("*** ARRAY BEFORE SORTING ***");
		printArray.printArray(arr);
		
		
		//*******************************************************
		// sorting algorithms
		
		// bubble sort
		BubbleSort bubbleSort = new BubbleSort();
		bubbleSort.bubbleSort(arr);
		
		System.out.println("*** ARRAY AFTER BUBBLE SORT ***");
		printArray.printArray(arr);
		
		// selection sort
		SelectionSort ss = new SelectionSort();
		ss.selectionSort(arr);
		
		System.out.println("*** ARRAY AFTER SELECTION SORT ***");
		printArray.printArray(arr);
		
		// insertion sort
		InsertionSort is = new InsertionSort();
		is.insertionSort(arr);
		
		System.out.println("*** ARRAY AFTER INSERTION SORT ***");
		printArray.printArray(arr);
		
		// merge sort
		MergeSort ms = new MergeSort();
		ms.mergeSort(arr, 0, arr.length - 1);
		
		System.out.println("*** ARRAY AFTER MERGE SORT ***");
		printArray.printArray(arr);

		// quick sort
		QuickSort qs = new QuickSort();
		qs.quickSort(arr, 0, arr.length - 1);
		
		System.out.println("*** ARRAY AFTER QUICK SORT ***");
		printArray.printArray(arr);
	}

}
