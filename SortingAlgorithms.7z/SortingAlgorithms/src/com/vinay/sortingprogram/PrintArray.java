package com.vinay.sortingprogram;

public class PrintArray {
	// method to print the array
	void printArray(int arr[]) {
		int arrLength = arr.length;

		for (int i = 0; i < arrLength; i++) {
			System.out.print(arr[i] + " ");
			System.out.println();
		}
	}

}
