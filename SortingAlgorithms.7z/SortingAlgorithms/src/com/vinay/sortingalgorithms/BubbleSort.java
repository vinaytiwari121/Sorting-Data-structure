package com.vinay.sortingalgorithms;

public class BubbleSort {
	
	// method to implement bubble sort algorithm
	public void bubbleSort(int arr[]) {
		int arrLength = arr.length;
		
		for(int i = 0; i < arrLength - 1; i++) {
			for(int j = 0; j < arrLength - i - 1; j++) {
				
				if(arr[j] > arr[j+1]) {
					
					// swap the values
					int temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
			}
		}
	}
}
