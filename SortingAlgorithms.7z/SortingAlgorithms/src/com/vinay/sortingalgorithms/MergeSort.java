package com.vinay.sortingalgorithms;

public class MergeSort {

	// Merges two subarrays of arr[].
	// First subarray is arr[l..m]
	// Second subarray is arr[m+1..r]
	
	void merge(int arr[], int start, int mid, int end) {
		// Find sizes of two subarrays to be merged
		int leftSubArrayElements = mid - start + 1;
		int rightSubArrayElements = end - mid;

		/* Create temp arrays */
		int leftSubArray[] = new int[leftSubArrayElements];
		int rightSubArray[] = new int[rightSubArrayElements];

		/* Copy data to temp arrays */
		for (int leftSubArrayIndex = 0; leftSubArrayIndex < leftSubArrayElements; ++leftSubArrayIndex)
			leftSubArray[leftSubArrayIndex] = arr[start + leftSubArrayIndex];

		for (int rightSubArrayIndex = 0; rightSubArrayIndex < rightSubArrayElements; ++rightSubArrayIndex)
			rightSubArray[rightSubArrayIndex] = arr[mid + 1 + rightSubArrayIndex];

		/* Merge the temp arrays */

		// Initial indexes of first and second subarrays
		int i = 0, j = 0;

		// Initial index of merged subarray array
		int k = start;
		while (i < leftSubArrayElements && j < rightSubArrayElements) {
			if (leftSubArray[i] <= rightSubArray[j]) {
				arr[k] = leftSubArray[i];
				i++;
			} else {
				arr[k] = rightSubArray[j];
				j++;
			}
			
			k++;
		}

		/* Copy remaining elements of leftSubArray[] if any */
		while (i < leftSubArrayElements) {
			arr[k] = leftSubArray[i];
			i++;
			k++;
		}

		/* Copy remaining elements of rightSubArray[] if any */
		while (j < rightSubArrayElements) {
			arr[k] = rightSubArray[j];
			j++;
			k++;
		}
	}

	// Main function that sorts arr[l..r] using
	// merge()
	public void mergeSort(int arr[], int start, int end) {
		if (start < end) {
			// Find the middle point
			int middle = (start + end) / 2;

			// Sort first and second halves
			mergeSort(arr, start, middle);
			mergeSort(arr, middle + 1, end);

			// Merge the sorted halves
			merge(arr, start, middle, end);
		}
	}
}
