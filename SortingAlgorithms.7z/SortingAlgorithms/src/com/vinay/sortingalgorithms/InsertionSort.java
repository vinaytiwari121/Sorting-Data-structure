package com.vinay.sortingalgorithms;

public class InsertionSort {

	// implementing insertion sort algorithm.
	public void insertionSort(int arr[]) {

		// finding the length of the given array.
		int arrLength = arr.length;

		for (int i = 1; i < arrLength; i++) {
			/*
			 * storing current element whose left side is checked for its correct position .
			 */

			int key = arr[i];
			int j = i - 1;

			/*
			 * check whether the adjacent element in left side is greater or less than the
			 * current element.
			 */
			while (j > 0 && arr[j] > key) {

				// moving the left side element to one position forward.
				arr[j + 1] = arr[j];
				j = j - 1;
			}

			// moving current element to its correct position.
			arr[j + 1] = key;
		}
	}
}
