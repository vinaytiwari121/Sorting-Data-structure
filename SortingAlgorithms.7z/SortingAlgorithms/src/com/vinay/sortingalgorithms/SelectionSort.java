package com.vinay.sortingalgorithms;

public class SelectionSort {

	// implementing selection sort algorithm.
	public void selectionSort(int arr[]) {

		// finding the length of the given array.
		int arrLength = arr.length;

		// reduces the effective size of the array by one in each iteration.
		for (int i = 0; i < arrLength - 1; i++) {

			// assuming the first element to be the minimum of the unsorted array .
			int minimum = i;

			// gives the effective size of the unsorted array .
			for (int j = i + 1; j < arrLength; j++) {

				if (arr[j] < arr[minimum]) { // finds the minimum values in given array.
					minimum = j;
				}
			}

			// swap the values.
			int temp = arr[minimum];
			arr[minimum] = arr[i];
			arr[i] = temp;
		}
	}
}
